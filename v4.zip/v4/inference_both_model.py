######## This inference_both_model.py is all in 1 and  supersedes  ##############################
########### all the inference.py inside each models individual training project ######################

import torch
#from data_class import S3DIS
from torch.utils.data.dataloader import DataLoader
#import config
import numpy as np
from run import create_model,calculate_shape_IoU,plot_conf_matrix
import plotly.graph_objects as go
import os
import torch.nn as nn
import utils.meter as meter
import sklearn.metrics as metrics
import argparse
import importlib
import csv  

#import pointnet2_sem_seg as MODEL

cats = ['ceiling','floor','wall','beam','column','window','door','chair','table','bookcase','sofa','board','clutter']
num_classes = 13

'''config.process = "TEST"
batch = 1
criterion = nn.CrossEntropyLoss()

def inplace_relu(m):
    classname = m.__class__.__name__
    if classname.find('ReLU') != -1:
        m.inplace=True'''

def writeCSV(avg_precision ,avg_recall, val_acc, avg_per_class_acc, IOU):
    print("Saving Evaluation Metrics.csv in the base folder.....")
    header = ['precision', 'recall', 'val_acc', 'avg_per_class_acc','IOU']
    data = [avg_precision*100 ,avg_recall*100, val_acc, avg_per_class_acc*100, IOU*100]
    with open('Evaluation Metrics.csv', 'w', newline ='') as f:
        writer = csv.writer(f)
        writer.writerow(header)   
        writer.writerow(data)
        f.close()


       
'''def main():
    # Let the cmd params dictate which model to load and what test set to use
    #pretrained_path = './model_best.pt' #.pt is pointCNN atm
    #TEST_FILE_PATH = 'C:\\Users\\mthossain\\OneDrive - Federation University Australia\\Desktop\\soft study\\Euclideon\\0 Code Base\\Eval_PointCNN_PointNetpp\\train_files.txt'
    TEST_FILE_PATH = './test_files.txt'
    parser = argparse.ArgumentParser()
    parser.add_argument('-ts', '--test_file_path', default=TEST_FILE_PATH)
    #parser.add_argument('-pre', '--pretrained_model_path', default=pretrained_path)
    parser.add_argument('-cm', '--confusion_matrix', type = int, default=0)
    parser.add_argument('-m', '--model', type = int, default=1)

    args = parser.parse_args()
    TEST_FILE_PATH = args.test_file_path
    #pretrained_path = args.pretrained_model_path
    confusion_matrix =  args.confusion_matrix
    
    if args.model == 0: # pointCNN
        net = create_model(config.base_model).to(config.device)
        checkpoint = torch.load('./model_best.pt','cpu')
        net.load_state_dict(checkpoint['best_model_dict']['acc'])
        
    ################################################
    #MODEL = importlib.import_module('pointnet2_sem_seg')
    elif args.model == 1: # PointNet++
        net = MODEL.get_model(num_classes).cuda()
        criterion = MODEL.get_loss().cuda()
        net.apply(inplace_relu)
    
        checkpoint = torch.load('./model_best.pth')
        #start_epoch = checkpoint['epoch']
        net.load_state_dict(checkpoint['model_state_dict'])
    #######################################
    net.to(config.device)
    
    valid_set = S3DIS(partition='test', path = TEST_FILE_PATH) # partition is ornamental
    valid_loader = DataLoader(valid_set, batch_size=batch, shuffle=False,
                                  num_workers=config.num_workers,  drop_last=False)
    
    results = evalu(valid_loader, net,html_path="test_output", calc_confusion_matrix = confusion_matrix)'''

def evalu(net, data_loader, config, calc_confusion_matrix=1, rtn_features=False,html_path="test_output"):
    net.eval()
    net.to(torch.device("cuda:0")) 
    softmax = torch.nn.Softmax(1)
    test_radius_ratio = 0.7
    test_smooth = 0.95   
    nc_model = config.num_classes
    test_probs = [np.zeros((l.shape[0], nc_model)) for l in data_loader.dataset.input_labels]
    # Core eval metrics. 
    # this meter thing enables automatic avg when a new item added, its different from list
    precision = meter.AverageValueMeter()
    recall = meter.AverageValueMeter()    
    confusion_matrix_meter = meter.ConfusionMeter(num_classes, normalized=True)
    
    loss_meter = meter.AverageValueMeter()
    acc_meter = meter.ClassErrorMeter(topk=[1, 5], accuracy=True)
    avg_acc_meter = meter.AverageValueMeter()
    Iou_meter = meter.AverageValueMeter()
    Iou_meter = meter.AverageValueMeter()
       
    '''N=len(data_loader.dataset)
    n_sample=int(0.05*len(data_loader.dataset))
    idx_samples=set(np.random.choice(np.arange(N), size=n_sample, replace=False))'''
                
    for i, batch in enumerate(data_loader):
        #batch_data=sample[0]
        #batch = data_loader.dataset.input_labels[i]
        '''tmp_set=set(np.arange(batch*i,(batch*i)+batch_data.size(0)))
        tmp_set=list(idx_samples.intersection(tmp_set))'''
        batch = batch.to(torch.device("cuda:0")) 
        #batch_labels = batch_labels.to(torch.device("cuda:0"))
        
        raw_out = net(batch, config)
        pred_choice = softmax(raw_out)
        
        stacked_probs = softmax(raw_out).cpu().detach().numpy()
        s_points = batch.points[0].cpu().numpy()
        lengths = batch.lengths[0].cpu().numpy()
        in_inds = batch.input_inds.cpu().numpy()
        cloud_inds = batch.cloud_inds.cpu().numpy()


        # Get predictions and labels per instance
        # ***************************************

        i0 = 0
        for b_i, length in enumerate(lengths):

            # Get prediction
            points = s_points[i0:i0 + length]
            probs = stacked_probs[i0:i0 + length]
            inds = in_inds[i0:i0 + length]
            c_i = cloud_inds[b_i]

            if 0 < test_radius_ratio < 1:
                mask = np.sum(points ** 2, axis=1) < (test_radius_ratio * config.in_radius) ** 2
                inds = inds[mask]
                probs = probs[mask]

            # Update current probs in whole cloud
            test_probs[c_i][inds] = test_smooth * test_probs[c_i][inds] + (1 - test_smooth) * probs
            i0 += length
        
        for i, file_path in enumerate(data_loader.dataset.files):

            # Insert false columns for ignored labels
            probs = np.array(test_probs[i], copy=True)
            for l_ind, label_value in enumerate(data_loader.dataset.label_values):
                if label_value in data_loader.dataset.ignored_labels:
                    probs = np.insert(probs, l_ind, 0, axis=1)
    
            # Predicted labels
            preds = data_loader.dataset.label_values[np.argmax(probs, axis=1)].astype(np.int32)
    
            # Targets
            targets = data_loader.dataset.input_labels[i]
                        
        stat_type = 'macro'
        prec,rec,_,_ = metrics.precision_recall_fscore_support(targets, preds, average = stat_type)
        precision.add(prec)
        recall.add(rec)
        acc_meter.add(probs,  targets)                      

        with torch.no_grad():
            confusion_matrix_meter.add(probs, target=targets)
        ###############################################################
        
        avg_acc_meter.add( metrics.balanced_accuracy_score(targets, preds))
        Iou_meter.add(np.mean(calculate_shape_IoU(targets, preds, None)))
        
    avg_precision = precision.value()[0]
    #std_avg_precision = precision.value()[1]
    avg_recall = recall.value()[0]
    #std_avg_recall = recall.value()[1]    
    val_acc = acc_meter.value(1) # name only train ashole val
    avg_per_class_acc = avg_acc_meter.value()[0]
    IOU = Iou_meter.value()[0]    
    
    outstr = '[ Validation summary ] avg_precision: %.6f, avg_recall: %.6f, validation_acc: %.6f, avg_per_class_acc: %.6f, val_ious: %.6f' % (avg_precision ,avg_recall, val_acc, avg_per_class_acc, np.mean(IOU))
    print(outstr)
    
    rst = avg_precision,avg_recall, val_acc,avg_per_class_acc, np.mean(IOU) 
    if calc_confusion_matrix:
        print('writing confusion matrix')
        with torch.no_grad():       
            conf_matrix = confusion_matrix_meter.value()
            plot_conf_matrix(cats, conf_matrix,
                                    save_file='./conf_matrix.pdf')
        
    else:
        print('skipping confusion matrix')
        
    writeCSV(avg_precision ,avg_recall, val_acc, avg_per_class_acc, np.mean(IOU))
        
    return rst
                    
#if __name__ == '__main__':
    #main()
