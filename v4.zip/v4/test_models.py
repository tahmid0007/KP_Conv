import signal
import os
import numpy as np
import sys
import torch
# Dataset
from datasets.ModelNet40 import *
from datasets.S3DIS import *
from datasets.SemanticKitti import *
from torch.utils.data import DataLoader
from inference_both_model import evalu
from utils.config import Config
from utils.tester import ModelTester
from models.architectures import KPCNN, KPFCNN

def model_choice(chosen_log):

    # Automatically retrieve the last trained model
    if chosen_log in ['last_ModelNet40', 'last_ShapeNetPart', 'last_S3DIS']:

        # Dataset name
        test_dataset = '_'.join(chosen_log.split('_')[1:])

        # List all training logs
        logs = np.sort([os.path.join('results', f) for f in os.listdir('results') if f.startswith('Log')])

        # Find the last log of asked dataset
        for log in logs[::-1]:
            log_config = Config()
            log_config.load(log)
            if log_config.dataset.startswith(test_dataset):
                chosen_log = log
                break

        if chosen_log in ['last_ModelNet40', 'last_ShapeNetPart', 'last_S3DIS']:
            raise ValueError('No log of the dataset "' + test_dataset + '" found')

    # Check if log exists
    if not os.path.exists(chosen_log):
        raise ValueError('The given log does not exists: ' + chosen_log)

    return chosen_log

if __name__ == '__main__':

    chosen_log = 'results/Log_2021-11-17_01-34-59'  # => ModelNet40
    
    # Choose the index of the checkpoint to load OR None if you want to load the current checkpoint
    chkp_idx = None
    chosen_log = model_choice(chosen_log)
    GPU_ID = '0'
    os.environ['CUDA_VISIBLE_DEVICES'] = GPU_ID
    # Find all checkpoints in the chosen training folder
    chkp_path = os.path.join(chosen_log, 'checkpoints')
    chkps = [f for f in os.listdir(chkp_path) if f[:4] == 'chkp']
    # Find which snapshot to restore
    if chkp_idx is None:
        chosen_chkp = 'current_chkp.tar'
    else:
        chosen_chkp = np.sort(chkps)[chkp_idx]
    chosen_chkp = os.path.join(chosen_log, 'checkpoints', chosen_chkp)
    print('Data Preparation')
    print('****************')
    
    set = 'validation'
    config = Config()
    config.load(chosen_log)
    config.dataset = 'S3DIS'
    config.validation_size = 1
    config.input_threads = 0
    path = './Data/S3DIS'
    
    test_dataset = S3DISDataset(config, path, set='validation', use_potentials=True)
    test_sampler = S3DISSampler(test_dataset)
    collate_fn = S3DISCollate

    test_loader = DataLoader(test_dataset,
                             batch_size=1,
                             sampler=test_sampler,
                             collate_fn=collate_fn,
                             num_workers=config.input_threads,
                             pin_memory=True)

    test_sampler.calibration(test_loader, verbose=True)

    print('\nModel Preparation')
    print('*****************')
    # Define network model
    t1 = time.time()
    net = KPFCNN(config, test_dataset.label_values, test_dataset.ignored_labels)
    tester = ModelTester(net, chkp_path=chosen_chkp)    
    print('\nStart test**********\n')
    tester.cloud_segmentation_test(net, test_loader, config)
    # to run inference_both for precision recall stuff
    #evalu(net, test_loader, config)
    print('Done in {:.1f}s\n'.format(time.time() - t1))
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    ##################################
    # Change model parameters for test
    ##################################

    # Change parameters for the test here. For example, you can stop augmenting the input data.

    #config.augment_noise = 0.0001
    #config.augment_symmetries = False
    #config.batch_num = 3
    #config.in_radius = 4
    

    # Initiate dataset
    '''if config.dataset == 'ModelNet40':
        test_dataset = ModelNet40Dataset(config, train=False)
        test_sampler = ModelNet40Sampler(test_dataset)
        collate_fn = ModelNet40Collate'''
    
    '''elif config.dataset == 'SemanticKitti':
        test_dataset = SemanticKittiDataset(config, set=set, balance_classes=False)
        test_sampler = SemanticKittiSampler(test_dataset)
        collate_fn = SemanticKittiCollate'''
        
    
    
    '''if config.dataset_task == 'classification':
        net = KPCNN(config)
    elif config.dataset_task in ['cloud_segmentation', 'slam_segmentation']:
        net = KPFCNN(config, test_dataset.label_values, test_dataset.ignored_labels)
    else:
        raise ValueError('Unsupported dataset_task for testing: ' + config.dataset_task)'''

    # Define a visualizer class
    
    
    
    
    
    
    
    
    
    # Training
    '''if config.dataset_task == 'classification':
        tester.classification_test(net, test_loader, config)
    elif config.dataset_task == 'cloud_segmentation':
        tester.cloud_segmentation_test(net, test_loader, config)
        #evalu(net, test_loader, config)
        
    elif config.dataset_task == 'slam_segmentation':
        tester.slam_segmentation_test(net, test_loader, config)
    else:
        raise ValueError('Unsupported dataset_task for testing: ' + config.dataset_task)'''