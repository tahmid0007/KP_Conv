from plotly.offline import plot
import warnings
warnings.filterwarnings("ignore")
import plotly.graph_objects as go
import time
import numpy as np

from utils.mayavi_visu import *


data = read_ply('C:\\Users\\mthossain\\OneDrive - Federation University Australia\\Desktop\\soft study\\Euclideon\\0 Code Base\\KP_Conv_Updated\\test\\Log_2021-11-17_01-34-59\\predictions\\S3DIS\\original_ply\\Area_2.ply')
points = np.vstack((data['x'], data['y'], data['z'])).T
#colors = np.vstack((data['red'], data['green'], data['blue'])).T
labels = data['preds']

# too heavy to render, downsample to see easily on light pc hardware.
fig = go.Figure(data=[go.Scatter3d( x=points[0:200000,0], y=points[0:200000,1], z=points[0:200000,2], mode='markers', marker=dict( size=1, color=labels[0:200000], colorscale='Viridis', opacity=0.8 ) )])
plot(fig) 
#fig.write_html(os.path.join("Full view","file"+str(tmp_set[kk])+"_pred.html"))